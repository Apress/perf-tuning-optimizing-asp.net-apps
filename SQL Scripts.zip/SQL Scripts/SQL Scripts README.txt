
SQL Scripts README

This folder contains 2 .sql scripts that must be run on your local copy
of the Northwind database. These scripts will create custom stored procedures
that are used by the sample projects for Chapters 2 and 6.

To run the .sql scripts, do the following:

1. Open Query Analyzer

2. Select the Northwind database from the dropdown list of available databases

3. Open each .sql script using the File - Open menu in Query Analyzer

4. Run each .sql script from the Query - Execute menu, or, by pressing F5
   when the script is visible in the current Query Analyzer window.

5. You will receive a status message indicating whether the scripts were successfully run.
   As long as you run the script as the database owner (dbo), the scripts should install successfully.


NOTE:

There are 2 custom .sql scripts, which are included both here, in the "SQL Scripts"
directory, and in the individual project directories where they apply:

Chapter 3: Ch3-DataAccess.sql
Chapter 6: Ch6-CustomerList.sql

You do not need to run these custom scripts unless you are running Chapters 3 or 6.
However, we would recommend doing so anyway.